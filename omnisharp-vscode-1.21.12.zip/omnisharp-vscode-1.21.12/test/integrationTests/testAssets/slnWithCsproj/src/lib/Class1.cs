﻿using System;

namespace lib
{
    public class Class1
    {
    }
}
