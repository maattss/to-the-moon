using System;

namespace singleCsproj
{
    class Completion
    {
        static void shouldHaveCompletions(string[] args)
        {
            Completion a = new Completion();
        }
    }
}
