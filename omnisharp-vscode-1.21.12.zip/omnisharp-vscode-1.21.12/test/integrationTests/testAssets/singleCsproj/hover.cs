using System;
namespace Test
{
   class testissue
   {
       ///<summary>Checks if object is tagged with the tag.</summary>
       /// <param name="gameObject">The game object.</param>
       /// <param name="tagName">Name of the tag.</param>
       /// <returns>Returns <c>true</c> if object is tagged with tag.</returns>
       
       public static bool Compare(int gameObject,string tagName)
       {
           return true;
       }
   }
}