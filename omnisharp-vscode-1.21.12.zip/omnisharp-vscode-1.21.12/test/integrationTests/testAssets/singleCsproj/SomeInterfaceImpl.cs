namespace ReAnalyze
{
    public class SomeInterfaceImpl: ISomeInterface
    {
    }
}