# OptionsSchema
OptionsSchema.json defines the type for Launch/Attach options.

# GenerateOptionsSchema
If there are any modifications to the OptionsSchema.json file. Please run `npm run gulp generateOptionsSchema` at the repo root.
This will call GenerateOptionsSchema and update the package.json file.
